rootProject.name = "cloudstream-latanime-provider"
include(":latanime")